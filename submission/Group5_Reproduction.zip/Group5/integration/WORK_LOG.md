# Integration record — 2026-09-07

## Initial evidence and gaps
- Clean working tree at start; fetched all remote branches. Main: 15c6d1c. No other local branches/worktrees with unpublished work.
- Integration branch: integration/final-submission-20260907; never merge/force-push main.
- ae99b01 contributes only four absent Part 4 documentation/notebook files; cherry-picked preserving authorship.
- Logistic regression notebook empty; existing CSVs insufficient to establish training provenance. Investigate all refs, then label any supplement honestly.
- Templates/course attachments search in progress. Names, IDs, contribution percentages and platform deadline require confirmation.

## Existing-tool inventory (verified with grep)
- part4/evaluation.py:12 feature_target — ID exclusion and labels.
- part4/evaluation.py:25 split_development — shared stratified development split.
- part4/evaluation.py:43 metrics — AP, ROC-AUC, >= decisions, confusion counts and costs.
- part4/evaluation.py:63,83 threshold_table/select_threshold — validation-only cost selection.
- part4/experiment.py:48,52,56 write_json/file_hash/save_predictions — serialization, SHA256 and float-preserving predictions.
- part4/experiment.py:63 paired_bootstrap — conditional paired intervals.
- part3/misclassification.py:29,38,62 derive_features/compute_profiles/case_snapshots.
- The benchmark/artifacts.py, report.py, metrics.py, matcher.py and review/executor.py mentioned in supplied generic instructions do not exist in this repository; do not invent imports.
- Existing duplicate JSON/hash helpers across experiment modules will be consolidated by controller.

## Exclusive ownership
- audit worker: integration/audit.py; integration/AUDIT_FINDINGS.md; results/final/audit*; results/final/model_comparison.csv; results/final/cost_comparison.csv.
- logistic worker: part1/; integration/LOGISTIC_PROVENANCE.md; results/logistic_supplement/; tests/test_part1.py.
- controller: all other files, shared helpers, dependencies, existing tests, report/slides/notes/checklist and final integration.

Workers reuse the above tools; no duplicate utilities. Propose new utilities before implementing. Every measurement script must be committed before execution. Workers request controller commit when ready; final report includes diff --stat, reused tools and new tools.

## Completed experiment integration
- Official UCI fresh-source cleaning replay exact; original download bytes were not preserved.
- Frozen experiment audit: 223/223 checks passed. Original CV fit jobs were not rerun.
- Legacy LR source was unrecoverable across refs/reflogs/unreachable objects; separate supplement predeclared in dd6f673 and run once.
- Historical train/test and RF metadata hashes explained with LF/CRLF evidence; RF environment-regeneration chronology retained.
- XGBoost platform probability drift at most 5.96e-8, with frozen decisions identical; reporting retains original probabilities.
- RF per-threshold case exports and group profiles are correct, including legitimately repeated extreme errors.
- Shared artifact writer/hash/prediction serializer and paired bootstrap now each have one implementation. DT retains only an adapter that computes model probabilities. No re-export __init__ modules added.
- Four artifact-reading notebooks executed in unified environment; source-writing notebooks retained with only redundant imports removed.
- Integration gate: 70 pytest tests passed, ruff all files passed, mypy 28 source files passed. Subsequent nonbehavioral DT serializer adapter is covered by the final gate.
- Six-page report rendered including all references, using 11pt body and normal math scripts. Teacher template missing, standard LaTeX fallback declared. Contact sheet and pages 3/6 visually inspected: no truncation/overlap, clear tables/charts.
- New test fixture structure replaces repeated setup; existing test files only, no new setup-heavy test file.

## Final delivery acceptance
- Report: six pages including references, 11pt body; actual PDF rendered with Tectonic. Full contact and detailed comparison/reference pages inspected.
- Presentation: 16 pages (12 main + 4 backup), five editable native charts, all 144 text boxes match the actual PPTX-rendered PDF. Explicit transitions and scripts agree across manifest, native notes and Markdown.
- Talk timing: 720 seconds, 180 per role; Q&A 180 seconds. Backup slides do not count in the main talk.
- Official signed LibreOffice 26.8.0.3 used to render the original PPTX after native Office/Keynote access failures. One backup card overflow was corrected and re-rendered; final dense slides/contact inspected.
- Final gate after document/precision changes: 70 tests passed (1.29s), full Ruff passed, mypy passed on 28 source files.
- Final main remote recheck: 15c6d1c, unchanged. All changes stay on integration branch. No course upload, teacher email, force-push or main merge.
- Remaining human information: member identities/actual contribution percentages, teacher template, final course platform deadline/date/upload fields, any original LR code outside the searched repository.

## Presentation and member details revision (2026-09-07)

- Applied user-supplied identities: Lei Peng G2509090C (part 1), Zhang Hanyu G2509091L (part 2), Zhou Xinzhe G2509033F (part 3), Xu Yiqun G2509092H (part 4). Equal contributions of 25% each are stored in `submission/team.json` and displayed in final materials.
- Replaced the report's three decorative partition cards with an ordinary partition/use table; removed the unused card image. The report remains six pages with three numbered figures.
- Redesigned the slide cover and body layouts with open chart space, a real partition table, an editable tree-rule diagram, thin rules and no theme shadows. Audience slides contain no rehearsal timing labels; timing remains in notes.
- Main slide ownership: Lei 1–3, Zhang 4–6, Zhou 7–9, Xu 10–12. All sixteen native PPTX note sections contain the full script, named speaker, student ID and transition. Four backup leads and 22 bilingual Q&A priorities are named explicitly.
- Rendered the actual PPTX with the official hash-verified, signed LibreOffice runtime. Inspected the report first/contribution pages, the slide contact sheet and detailed cost/uncertainty slides. Delivery validation checks all 182 nonempty text boxes against PDF, all scripts against native notes, and names/IDs against report/cover/Q&A. Experiment CSVs and frozen artifacts were not changed.
- Full repository gate after layout/identity changes: 70 pytest tests passed; Ruff passed; mypy passed for 28 source files. Subsequent rendering refinements were checked with Ruff/mypy and the delivery validator.
